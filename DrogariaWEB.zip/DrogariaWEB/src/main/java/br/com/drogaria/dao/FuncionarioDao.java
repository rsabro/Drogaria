package br.com.drogaria.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.PreparedStatement;

import br.com.drogaria.areas.Funcionario;
import br.com.drogaria.controller.ConnectionFactory;

public class FuncionarioDao {
	private Connection connection;
	
	public FuncionarioDao() {
		this.connection = new ConnectionFactory().getConnection();
	}
	
	//Create
	public void adiciona(Funcionario funcionario) {
		String sql = "insert into funcionario " + 
				"(id, nome, idade, cpf, re)" +
				" values (?,?,?,?,?)";
		
		try {
			PreparedStatement stmt = (PreparedStatement) connection.prepareStatement(sql);
			
			stmt.setInt(1, funcionario.getId());
			stmt.setString(2, funcionario.getNome());
			stmt.setInt(3, funcionario.getIdade());
			stmt.setLong(4, funcionario.getCpf());
			stmt.setInt(5, funcionario.getRe());
			
			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			// TODO: handle exception
			throw new RuntimeException(e);
		}
	}
	
	//Read
	public List<Funcionario> getLista() {
		try {
			List<Funcionario> funcionarios = new ArrayList<Funcionario>();
			PreparedStatement stmt = (PreparedStatement) this.connection.prepareStatement("select*from funcionario");
			ResultSet rs = stmt.executeQuery();
			
			while (rs.next()) {
				Funcionario funcionario = new Funcionario();
				funcionario.setId(rs.getInt("id"));
				funcionario.setCpf(rs.getLong("cpf"));
				funcionario.setNome(rs.getString("nome"));
				funcionario.setIdade(rs.getInt("idade"));
				funcionario.setRe(rs.getInt("re"));
				
				funcionarios.add(funcionario);
			}
			rs.close();
			stmt.close();
			return funcionarios;
		} catch (SQLException e) {
			// TODO: handle exception
			throw new RuntimeException(e);
		}
	}
	
	//Update
	public void altera(Funcionario funcionario) {
		String sql = "update funcionario set nome=?, idade=?, cpf=?, re=? where id=?";
		try {
			PreparedStatement stmt = (PreparedStatement) connection.prepareStatement(sql);
			stmt.setString(1, funcionario.getNome());
			stmt.setInt(2, funcionario.getIdade());
			stmt.setLong(3, funcionario.getCpf());
			stmt.setInt(4, funcionario.getRe());
			stmt.setInt(5, funcionario.getId());
			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			// TODO: handle exception
			throw new RuntimeException(e);
		}
	}
	
	//Delete
	public void remove(Funcionario funcionario) {
        try {
            PreparedStatement stmt = (PreparedStatement) connection.prepareStatement("delete from funcionario where id=?");
            stmt.setLong(1, funcionario.getId());
            stmt.execute();
            stmt.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }	
}
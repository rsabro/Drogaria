package br.com.drogaria.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.PreparedStatement;

import br.com.drogaria.areas.Fornecedor;
import br.com.drogaria.controller.ConnectionFactory;

public class FornecedorDao {
	private Connection connection;
	
	public FornecedorDao() {
		this.connection = new ConnectionFactory().getConnection();
	}
	
	//Create
	public void adiciona(Fornecedor fornecedor) {
		String sql = "insert into fornecedor (nome) values (?)";
		
		try {
			PreparedStatement stmt = (PreparedStatement) connection.prepareStatement(sql);
			
			stmt.setString(1, fornecedor.getNome());
			
			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			// TODO: handle exception
			throw new RuntimeException(e);
		}
	}
	
	//Read
		public List<Fornecedor> getLista() {
			try {
				List<Fornecedor> fornecedores = new ArrayList<Fornecedor>();
				PreparedStatement stmt = (PreparedStatement) this.connection.prepareStatement("select*from fornecedor");
				ResultSet rs = stmt.executeQuery();
				
				while (rs.next()) {
					Fornecedor fornecedor = new Fornecedor();
					fornecedor.setNome(rs.getString("nome"));
					
					fornecedores.add(fornecedor);
				}
				rs.close();
				stmt.close();
				return fornecedores;
			} catch (SQLException e) {
				// TODO: handle exception
				throw new RuntimeException(e);
			}
		}
		
		//Update
		public void altera(Fornecedor fornecedor) {
			String sql = "update fornecedor set nome=? where nome=?";
			try {
				PreparedStatement stmt = (PreparedStatement) connection.prepareStatement(sql);
				stmt.setString(1, fornecedor.getNome());

				stmt.execute();
				stmt.close();
			} catch (SQLException e) {
				// TODO: handle exception
				throw new RuntimeException(e);
			}
		}
		
		//Delete
		public void remove(Fornecedor fornecedor) {
	        try {
	            PreparedStatement stmt = (PreparedStatement) connection.prepareStatement("delete from fornecedor where nome=?");
	            stmt.setString(1, fornecedor.getNome());
	            
	            stmt.execute();
	            stmt.close();
	        } catch (SQLException e) {
	            throw new RuntimeException(e);
	        }
	    }
}
package br.com.drogaria.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.PreparedStatement;

import br.com.drogaria.areas.Produto;
import br.com.drogaria.controller.ConnectionFactory;

public class ProdutoDao {
	private Connection connection;
	
	public ProdutoDao() {
		this.connection = new ConnectionFactory().getConnection();
	}
	
	//Create
	public void adiciona(Produto produto) {
		String sql = "insert into produto (nome, valor, validade) values (?,?,?)";
		
		try {
			PreparedStatement stmt = (PreparedStatement) connection.prepareStatement(sql);
			
			stmt.setString(1, produto.getNome());
			stmt.setFloat(2, produto.getValor());
			stmt.setDate(3, produto.getValidade());
			
			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			// TODO: handle exception
			throw new RuntimeException(e);
		}
	}
	
	//Read
		public List<Produto> getLista() {
			try {
				List<Produto> produtos = new ArrayList<Produto>();
				PreparedStatement stmt = (PreparedStatement) this.connection.prepareStatement("select*from produto");
				ResultSet rs = stmt.executeQuery();
				
				while (rs.next()) {
					Produto produto = new Produto();
					produto.setNome(rs.getString("nome"));
					produto.setValor(rs.getFloat("valor"));
					produto.setValidade(rs.getDate("validade"));
					
					produtos.add(produto);
				}
				rs.close();
				stmt.close();
				return produtos;
			} catch (SQLException e) {
				// TODO: handle exception
				throw new RuntimeException(e);
			}
		}
		
		//Update
		public void altera(Produto produto) {
			String sql = "update produto set nome=?, valor=?, validade=?";
			try {
				PreparedStatement stmt = (PreparedStatement) connection.prepareStatement(sql);
				stmt.setString(1, produto.getNome());
				stmt.setFloat(2, produto.getValor());
				stmt.setDate(3, produto.getValidade());

				stmt.execute();
				stmt.close();
			} catch (SQLException e) {
				// TODO: handle exception
				throw new RuntimeException(e);
			}
		}
		
		//Delete
		public void remove(Produto produto) {
	        try {
	            PreparedStatement stmt = (PreparedStatement) connection.prepareStatement("delete from produto where nome=?");
	            stmt.setString(1, produto.getNome());
	            
	            stmt.execute();
	            stmt.close();
	        } catch (SQLException e) {
	            throw new RuntimeException(e);
	        }
	    }
}
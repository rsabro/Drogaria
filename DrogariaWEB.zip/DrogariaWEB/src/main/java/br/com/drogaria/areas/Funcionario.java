package br.com.drogaria.areas;

public class Funcionario {
	private int id;
	private String nome;
	private int idade;
	private long cpf;
	private int re;

	public int getId() {
		return id;
	}
	public String getNome() {
		return nome;
	}
	public int getIdade() {
		return idade;
	}
	public long getCpf() {
		return cpf;
	}
	public int getRe() {
		return re;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	public void setCpf(long cpf) {
		this.cpf = cpf;
	}
	public void setRe(int re) {
		this.re = re;
	}
}
package br.com.drogaria.controller;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;


@SuppressWarnings("deprecation")
@ManagedBean 
@SessionScoped
public class LoginBean {


	private Usuario usuario = new Usuario();

    public String doEfetuarLogin(){
                   if("admin".equals(usuario.getNome()) && "admin".equals(usuario.getSenha())){
                                   return "inicio";
                   }

          FacesMessage msg = new FacesMessage("Usu�rio ou senha inv�lido!");

          FacesContext.getCurrentInstance().addMessage("erro", msg);
          return null;
        }


      public Usuario getUsuario() {
        return usuario;
      }

      public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
      }
}
/**
 * 
 */

function teste(){
	alert("Aqui é login.js");
}